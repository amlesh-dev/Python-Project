# MCQ_Test_Portal
Django framework

frontend - html,css, bootstrap

backend - python

database- sqlite3 (inbuild django framework database)
