from django.apps import AppConfig


class McqTestConfig(AppConfig):
    name = 'MCQ_Test'
